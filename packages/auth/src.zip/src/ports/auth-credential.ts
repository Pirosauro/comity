export type AuthCredential = { kind: string; value: string };
