import type { Result } from "../core/types.js";
import type { AuthCredential } from "./auth-credential.js";

export interface AuthCredentialExtractor<
  R = unknown, // Context (eg. Request-like type)
  O extends Record<string, unknown> = {}
> {
  extract(context: R, options?: O): Result<AuthCredential, never> | null;
}
