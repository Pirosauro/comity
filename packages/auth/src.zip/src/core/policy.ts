/**
 * Reasonable default policy.
 *
 * DEFAULT_ASSURANCE_POLICY is a reference policy, not a security guarantee.
 * Applications are expected to:
 * - override it
 * - version it
 * - or replace it entirely
 */
export const DEFAULT_ASSURANCE_POLICY = {
  methodWeights: {
    password: 15,

    otp: 25,
    push_auth: 25,

    biometric: 30,

    passkey: 40,
    hardware_token: 40,

    oauth2: 20,
    oidc: 20,
    saml2: 20,
  },

  deviceTrustedBonus: 10,

  maxAgeSeconds: 24 * 60 * 60, // 24h
  agePenaltyFactor: 0.7,
} as const;

export type AuthAssurancePolicyConfig = typeof DEFAULT_ASSURANCE_POLICY;
