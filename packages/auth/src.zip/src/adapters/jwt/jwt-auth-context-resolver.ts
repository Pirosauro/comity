import type { AuthContextResolver } from "../../ports/auth-context-resolver.js";
import type { AuthCredential } from "../../ports/auth-credential.js";
import type { AuthContext } from "../../ports/auth-context.js";
import type { Result } from "../../core/types.js";
import type { JwtFacade } from "./jwt-facade.js";
import type { JwtSessionMapper } from "./jwt-session-mapper.js";

export interface JwtAuthContextResolverOptions<
  C,
  S extends Record<string, unknown>,
  I,
  V extends string
> {
  /** JWT facade */
  jwt: JwtFacade<C, V>;

  /** Maps JWT claims to a session object */
  mapSession: JwtSessionMapper<C, S>;

  /** Optional mapper from JWT claims to identity information */
  mapIdentity?: (claims: C) => I;
}

export function createJwtAuthContextResolver<
  C = unknown,
  S extends Record<string, unknown> = {},
  I extends Record<string, unknown> = {},
  V extends string = string
>(
  options: JwtAuthContextResolverOptions<C, S, I, V>
): AuthContextResolver<I, S, V | "invalid_credential"> {
  return {
    async resolve(
      credential: AuthCredential,
      now: number
    ): Promise<Result<AuthContext<S, I>, V | "invalid_credential">> {
      if (!credential?.value) {
        return {
          ok: false,
          reason: "invalid_credential",
        };
      }

      const verified = await options.jwt.verify(credential.value, now);

      if (!verified.ok) {
        return verified;
      }

      const session = options.mapSession(verified.value!.claims);

      return {
        ok: true,
        value: {
          session,
          ...(verified.value!.claims && options.mapIdentity
            ? { identity: options.mapIdentity(verified.value!.claims) }
            : {}),
        },
      };
    },
  };
}
