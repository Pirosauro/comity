import type { Result } from "../../core/types.js";

export interface JwtVerifyResult<C> {
  /** Verified JWT claims */
  readonly claims: C;
}

export interface JwtSignInput<C> {
  /** Claims to be signed into the JWT */
  readonly claims: C;

  /** Issued at (iat) - seconds since epoch when token was issued */
  readonly issuedAt: number;

  /** Expiration time (exp) - seconds since epoch when token expires */
  readonly expiresAt?: number;
}

export interface JwtFacade<
  C = unknown,
  V extends string = string,
  S extends string = string
> {
  /**
   * Verifies a JWT and returns its claims.
   */
  verify(token: string, now: number): Promise<Result<JwtVerifyResult<C>, V>>;

  /**
   * Signs claims into a JWT.
   */
  sign(input: JwtSignInput<C>): Promise<Result<string, S>>;
}
