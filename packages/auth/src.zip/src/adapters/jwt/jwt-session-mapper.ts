import type { AuthSession } from "../../core/types.js";

/**
 * Maps verified JWT claims into an AuthSession.
 */
export type JwtSessionMapper<C, S extends Record<string, unknown> = {}> = (
  claims: C
) => AuthSession<S>;
