import type { Result } from "../../core/types.js";
import type { AuthService } from "../../core/service.js";
import type { AuthCredentialExtractor } from "../../ports/auth-credential-extractor.js";
import type { AuthContextResolver } from "../../ports/auth-context-resolver.js";
import type { AuthContext } from "../../ports/auth-context.js";

import { ValidationError } from "@comity/core/errors";

export interface HttpAuthAdapterOptions<
  R,
  I extends Record<string, unknown>,
  S extends Record<string, unknown>,
  E extends string
> {
  authService: AuthService;

  credentialExtractor: AuthCredentialExtractor<R>;

  contextResolver: AuthContextResolver<I, S, E>;

  now?: () => number;
}

export class HttpAuthAdapter<
  R,
  I extends Record<string, unknown>,
  S extends Record<string, unknown>,
  E extends string
> {
  private readonly now: () => number;

  constructor(private readonly options: HttpAuthAdapterOptions<R, I, S, E>) {
    this.now = options.now ?? (() => Math.floor(Date.now() / 1000));
  }

  /**
   * Authorize request (step-up aware)
   */
  async authorize(
    request: R,
    requirement = {}
  ): Promise<
    Result<
      {
        context: AuthContext<S, I>;
        decision: ReturnType<AuthService["authorize"]>["value"];
      },
      E
    >
  > {
    const credential = this.options.credentialExtractor.extract(request);

    if (!credential) {
      return {
        ok: false,
        reason: "invalid_credential" as E,
      };
    }

    const resolved = await this.options.contextResolver.resolve(
      credential,
      this.now()
    );

    if (!resolved.ok) {
      return resolved;
    }

    const decision = this.options.authService.authorize(
      resolved.value!.session,
      requirement,
      this.now()
    );

    if (!decision.ok) {
      throw new ValidationError("Session validation failed", {
        details: decision.error,
      });
    }

    return {
      ok: true,
      value: {
        context: resolved.value!,
        decision: decision.value,
      },
    };
  }

  /**
   * Refresh session
   */
  async refresh(
    request: Request,
    requirement = {}
  ): Promise<
    Result<
      {
        context: AuthContext<SessionMeta, IdentityMeta>;
        decision: ReturnType<AuthService["refresh"]>["value"];
      },
      ResolveError
    >
  > {
    const credential = this.options.credentialExtractor.extract(request);

    if (!credential) {
      return {
        ok: false,
        error: "invalid_credential" as ResolveError,
      };
    }

    const resolved = await this.options.contextResolver.resolve(
      credential,
      this.now()
    );

    if (!resolved.ok) {
      return resolved;
    }

    const decision = this.options.authService.refresh(
      resolved.value.session,
      requirement,
      this.now()
    );

    if (!decision.ok) {
      throw new ValidationError("Session refresh failed", {
        details: decision.error,
      });
    }

    return {
      ok: true,
      value: {
        context: resolved.value,
        decision: decision.value,
      },
    };
  }
}
